(function(){function u(){const e=m(),t=h();return{html:g(),url:window.location.href,jsonLd:e,ogData:t,title:document.title}}function m(){const e=document.querySelectorAll('script[type="application/ld+json"]');for(const t of e)try{const o=JSON.parse(t.textContent||"");return o["@type"]==="Product"||o["@type"]==="RealEstateListing",o}catch{}return null}function h(){const e={};return document.querySelectorAll('meta[property^="og:"]').forEach(t=>{const o=t.getAttribute("property")?.replace("og:",""),n=t.getAttribute("content");o&&n&&(e[o]=n)}),document.querySelectorAll('meta[name^="twitter:"]').forEach(t=>{const o=t.getAttribute("name")?.replace("twitter:",""),n=t.getAttribute("content");o&&n&&!e[o]&&(e[o]=n)}),e}function g(){const e=["main",'[role="main"]',"article",".listing-detail",".property-detail","#content",".content"];let t=null;for(const i of e)if(t=document.querySelector(i),t)break;t||(t=document.body);const o=t.cloneNode(!0);return["script","style","noscript","iframe","svg","nav","header","footer",".cookie-banner",".advertisement",".ads",'[role="banner"]','[role="navigation"]','[role="contentinfo"]'].forEach(i=>{o.querySelectorAll(i).forEach(l=>l.remove())}),o.innerHTML}const d="search-room-overlay",r="search-room-overlay-button",a="search-room-tooltip",f={"homegate.ch":/^\/(buy|kaufen|acheter|acquistare|rent|mieten|louer|affittare)\/(\d+)\/?$/,"immoscout24.ch":/^\/(buy|kaufen|acheter|acquistare|rent|mieten|louer|affittare)\/(\d+)\/?$/,"comparis.ch":/\/immobilien\/marktplatz\/.*?\/details\/show\/\d+/,"immobilier.ch":/^\/(fr|de|en|it)\/(louer|acheter|mieten|kaufen|rent|buy)\/.*-(\d+)$/};function y(){try{const e=window.location.hostname.toLowerCase(),t=window.location.pathname;for(const[o,n]of Object.entries(f))if(e.includes(o)&&n.test(t))return console.log("[Search Room] PDP detected:",e,t),!0;return console.log("[Search Room] Not a PDP:",e,t),!1}catch(e){return console.error("[Search Room] Domain check error:",e),!1}}function x(){if(document.getElementById("search-room-styles"))return;const e=document.createElement("style");e.id="search-room-styles",e.textContent=`
    #${d} {
      position: fixed;
      bottom: 24px;
      right: 24px;
      z-index: 2147483647;
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
    }
    
    #${r} {
      display: flex;
      align-items: center;
      gap: 8px;
      padding: 14px 20px;
      background: linear-gradient(135deg, #e5007d 0%, #c4006a 100%);
      color: white;
      border: none;
      border-radius: 50px;
      font-size: 14px;
      font-weight: 600;
      cursor: pointer;
      box-shadow: 0 4px 16px rgba(229, 0, 125, 0.4), 0 2px 4px rgba(0, 0, 0, 0.1);
      transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
      white-space: nowrap;
    }
    
    #${r}:hover {
      transform: translateY(-2px) scale(1.02);
      box-shadow: 0 8px 24px rgba(229, 0, 125, 0.5), 0 4px 8px rgba(0, 0, 0, 0.15);
    }
    
    #${r}:active {
      transform: translateY(0) scale(0.98);
    }
    
    #${r} svg {
      flex-shrink: 0;
    }
    
    #${a} {
      position: fixed;
      bottom: 90px;
      right: 24px;
      width: 300px;
      background: white;
      border-radius: 16px;
      box-shadow: 0 12px 40px rgba(0, 0, 0, 0.15), 0 4px 12px rgba(0, 0, 0, 0.1);
      z-index: 2147483647;
      padding: 20px;
      animation: slideUp 0.2s ease-out;
    }
    
    @keyframes slideUp {
      from {
        opacity: 0;
        transform: translateY(10px);
      }
      to {
        opacity: 1;
        transform: translateY(0);
      }
    }
    
    .sr-tooltip-header {
      display: flex;
      align-items: center;
      gap: 12px;
      margin-bottom: 16px;
    }
    
    .sr-tooltip-icon {
      width: 40px;
      height: 40px;
      background: linear-gradient(135deg, #e5007d 0%, #c4006a 100%);
      border-radius: 10px;
      display: flex;
      align-items: center;
      justify-content: center;
      flex-shrink: 0;
    }
    
    .sr-tooltip-title {
      font-weight: 600;
      font-size: 15px;
      color: #111827;
      margin: 0;
    }
    
    .sr-tooltip-subtitle {
      font-size: 13px;
      color: #6b7280;
      margin: 0;
    }
    
    .sr-tooltip-content {
      background: #f9fafb;
      border-radius: 10px;
      padding: 14px;
      margin-bottom: 16px;
    }
    
    .sr-tooltip-instruction {
      display: flex;
      align-items: center;
      gap: 10px;
      font-size: 13px;
      color: #374151;
    }
    
    .sr-tooltip-step {
      width: 24px;
      height: 24px;
      background: #e5007d;
      color: white;
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 12px;
      font-weight: 600;
      flex-shrink: 0;
    }
    
    .sr-tooltip-close {
      position: absolute;
      top: 12px;
      right: 12px;
      background: none;
      border: none;
      width: 28px;
      height: 28px;
      border-radius: 8px;
      cursor: pointer;
      color: #9ca3af;
      display: flex;
      align-items: center;
      justify-content: center;
      transition: all 0.15s;
    }
    
    .sr-tooltip-close:hover {
      background: #f3f4f6;
      color: #6b7280;
    }
    
    .sr-tooltip-link {
      display: block;
      text-align: center;
      color: #e5007d;
      font-size: 13px;
      font-weight: 500;
      text-decoration: none;
      padding: 10px;
      border-radius: 8px;
      transition: background 0.15s;
    }
    
    .sr-tooltip-link:hover {
      background: #fdf2f8;
    }
  `,document.head.appendChild(e)}function b(){const e=document.createElement("div");return e.id=d,e.innerHTML=`
    <button id="${r}" type="button">
      <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <path d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6"></path>
      </svg>
      <span>Save to Search Room</span>
    </button>
  `,e}function v(){const e=document.createElement("div");return e.id=a,e.innerHTML=`
    <button class="sr-tooltip-close" type="button" aria-label="Close">
      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <path d="M18 6L6 18M6 6l12 12"></path>
      </svg>
    </button>
    <div class="sr-tooltip-header">
      <div class="sr-tooltip-icon">
        <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
          <path d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6"></path>
        </svg>
      </div>
      <div>
        <p class="sr-tooltip-title">Save this listing</p>
        <p class="sr-tooltip-subtitle">Add to your Search Room</p>
      </div>
    </div>
    <div class="sr-tooltip-content">
      <div class="sr-tooltip-instruction">
        <span class="sr-tooltip-step">1</span>
        <span>Click the <strong>Search Room</strong> extension icon in your browser toolbar</span>
      </div>
    </div>
    <a href="https://search-room.ch" target="_blank" rel="noopener noreferrer" class="sr-tooltip-link">
      Open Search Room →
    </a>
  `,e}async function c(){if(console.log("[Search Room] showOverlay called"),document.getElementById(d)){console.log("[Search Room] Overlay already exists");return}if(!y()){console.log("[Search Room] Not a supported domain, skipping overlay");return}try{const n=(await chrome.storage.sync.get("overlayEnabled")).overlayEnabled??!0;if(console.log("[Search Room] Overlay enabled setting:",n),!n){console.log("[Search Room] Overlay disabled in settings");return}}catch(o){console.error("[Search Room] Failed to get storage:",o)}console.log("[Search Room] Injecting overlay"),x();const e=b();document.body.appendChild(e);const t=document.getElementById(r);t&&t.addEventListener("click",w),console.log("[Search Room] Overlay injected successfully")}function p(){const e=document.getElementById(d);e&&e.remove(),s()}function s(){const e=document.getElementById(a);e&&e.remove()}function w(e){if(e.preventDefault(),e.stopPropagation(),document.getElementById(a)){s();return}k()}function k(){const e=v();document.body.appendChild(e);const t=e.querySelector(".sr-tooltip-close");t&&t.addEventListener("click",o=>{o.stopPropagation(),s()}),setTimeout(()=>{const o=n=>{const i=document.getElementById(a),l=document.getElementById(r);i&&l&&!i.contains(n.target)&&!l.contains(n.target)&&(s(),document.removeEventListener("click",o))};document.addEventListener("click",o)},100)}async function S(){console.log("[Search Room] initOverlay called, readyState:",document.readyState),document.readyState==="loading"?document.addEventListener("DOMContentLoaded",()=>{console.log("[Search Room] DOMContentLoaded fired"),c()}):setTimeout(()=>{c()},1e3);try{chrome.storage.onChanged.addListener((e,t)=>{t==="sync"&&e.overlayEnabled&&(console.log("[Search Room] Overlay setting changed:",e.overlayEnabled.newValue),e.overlayEnabled.newValue?c():p())})}catch(e){console.error("[Search Room] Failed to add storage listener:",e)}}chrome.runtime.onMessage.addListener((e,t,o)=>{if(e.type==="EXTRACT_CONTENT"){try{const n=u();o?.(n)}catch(n){console.error("[Search Room] Failed to extract content:",n),o?.({html:document.body.innerHTML,url:window.location.href,jsonLd:null,ogData:{},title:document.title})}return!0}else if(e.type==="OVERLAY_SETTING_CHANGED")return e.enabled?c():p(),!1;return!1});S();console.log("[Search Room] Content script loaded on:",window.location.hostname);
})()

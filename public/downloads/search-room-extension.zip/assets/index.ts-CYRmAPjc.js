(function(){function u(){const t=h(),o=m();return{html:g(),url:window.location.href,jsonLd:t,ogData:o,title:document.title}}function h(){const t=document.querySelectorAll('script[type="application/ld+json"]');for(const o of t)try{const e=JSON.parse(o.textContent||"");return e["@type"]==="Product"||e["@type"]==="RealEstateListing",e}catch{}return null}function m(){const t={};return document.querySelectorAll('meta[property^="og:"]').forEach(o=>{var r;const e=(r=o.getAttribute("property"))==null?void 0:r.replace("og:",""),n=o.getAttribute("content");e&&n&&(t[e]=n)}),document.querySelectorAll('meta[name^="twitter:"]').forEach(o=>{var r;const e=(r=o.getAttribute("name"))==null?void 0:r.replace("twitter:",""),n=o.getAttribute("content");e&&n&&!t[e]&&(t[e]=n)}),t}function g(){const t=["main",'[role="main"]',"article",".listing-detail",".property-detail","#content",".content"];let o=null;for(const r of t)if(o=document.querySelector(r),o)break;o||(o=document.body);const e=o.cloneNode(!0);return["script","style","noscript","iframe","svg","nav","header","footer",".cookie-banner",".advertisement",".ads",'[role="banner"]','[role="navigation"]','[role="contentinfo"]'].forEach(r=>{e.querySelectorAll(r).forEach(l=>l.remove())}),e.innerHTML}const d="search-room-overlay",i="search-room-overlay-button",a="search-room-tooltip",f=["homegate.ch","immoscout24.ch","tutti.ch","anibis.ch"];function y(){try{const t=window.location.hostname.toLowerCase(),o=f.some(e=>t.includes(e));return console.log("[Search Room] Domain check:",t,"supported:",o),o}catch(t){return console.error("[Search Room] Domain check error:",t),!1}}function x(){if(document.getElementById("search-room-styles"))return;const t=document.createElement("style");t.id="search-room-styles",t.textContent=`
    #${d} {
      position: fixed;
      bottom: 24px;
      right: 24px;
      z-index: 2147483647;
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
    }
    
    #${i} {
      display: flex;
      align-items: center;
      gap: 8px;
      padding: 14px 20px;
      background: linear-gradient(135deg, #e5007d 0%, #c4006a 100%);
      color: white;
      border: none;
      border-radius: 50px;
      font-size: 14px;
      font-weight: 600;
      cursor: pointer;
      box-shadow: 0 4px 16px rgba(229, 0, 125, 0.4), 0 2px 4px rgba(0, 0, 0, 0.1);
      transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
      white-space: nowrap;
    }
    
    #${i}:hover {
      transform: translateY(-2px) scale(1.02);
      box-shadow: 0 8px 24px rgba(229, 0, 125, 0.5), 0 4px 8px rgba(0, 0, 0, 0.15);
    }
    
    #${i}:active {
      transform: translateY(0) scale(0.98);
    }
    
    #${i} svg {
      flex-shrink: 0;
    }
    
    #${a} {
      position: fixed;
      bottom: 90px;
      right: 24px;
      width: 300px;
      background: white;
      border-radius: 16px;
      box-shadow: 0 12px 40px rgba(0, 0, 0, 0.15), 0 4px 12px rgba(0, 0, 0, 0.1);
      z-index: 2147483647;
      padding: 20px;
      animation: slideUp 0.2s ease-out;
    }
    
    @keyframes slideUp {
      from {
        opacity: 0;
        transform: translateY(10px);
      }
      to {
        opacity: 1;
        transform: translateY(0);
      }
    }
    
    .sr-tooltip-header {
      display: flex;
      align-items: center;
      gap: 12px;
      margin-bottom: 16px;
    }
    
    .sr-tooltip-icon {
      width: 40px;
      height: 40px;
      background: linear-gradient(135deg, #e5007d 0%, #c4006a 100%);
      border-radius: 10px;
      display: flex;
      align-items: center;
      justify-content: center;
      flex-shrink: 0;
    }
    
    .sr-tooltip-title {
      font-weight: 600;
      font-size: 15px;
      color: #111827;
      margin: 0;
    }
    
    .sr-tooltip-subtitle {
      font-size: 13px;
      color: #6b7280;
      margin: 0;
    }
    
    .sr-tooltip-content {
      background: #f9fafb;
      border-radius: 10px;
      padding: 14px;
      margin-bottom: 16px;
    }
    
    .sr-tooltip-instruction {
      display: flex;
      align-items: center;
      gap: 10px;
      font-size: 13px;
      color: #374151;
    }
    
    .sr-tooltip-step {
      width: 24px;
      height: 24px;
      background: #e5007d;
      color: white;
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 12px;
      font-weight: 600;
      flex-shrink: 0;
    }
    
    .sr-tooltip-close {
      position: absolute;
      top: 12px;
      right: 12px;
      background: none;
      border: none;
      width: 28px;
      height: 28px;
      border-radius: 8px;
      cursor: pointer;
      color: #9ca3af;
      display: flex;
      align-items: center;
      justify-content: center;
      transition: all 0.15s;
    }
    
    .sr-tooltip-close:hover {
      background: #f3f4f6;
      color: #6b7280;
    }
    
    .sr-tooltip-link {
      display: block;
      text-align: center;
      color: #e5007d;
      font-size: 13px;
      font-weight: 500;
      text-decoration: none;
      padding: 10px;
      border-radius: 8px;
      transition: background 0.15s;
    }
    
    .sr-tooltip-link:hover {
      background: #fdf2f8;
    }
  `,document.head.appendChild(t)}function v(){const t=document.createElement("div");return t.id=d,t.innerHTML=`
    <button id="${i}" type="button">
      <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <path d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6"></path>
      </svg>
      <span>Save to Search Room</span>
    </button>
  `,t}function b(){const t=document.createElement("div");return t.id=a,t.innerHTML=`
    <button class="sr-tooltip-close" type="button" aria-label="Close">
      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <path d="M18 6L6 18M6 6l12 12"></path>
      </svg>
    </button>
    <div class="sr-tooltip-header">
      <div class="sr-tooltip-icon">
        <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
          <path d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6"></path>
        </svg>
      </div>
      <div>
        <p class="sr-tooltip-title">Save this listing</p>
        <p class="sr-tooltip-subtitle">Add to your Search Room</p>
      </div>
    </div>
    <div class="sr-tooltip-content">
      <div class="sr-tooltip-instruction">
        <span class="sr-tooltip-step">1</span>
        <span>Click the <strong>Search Room</strong> extension icon in your browser toolbar</span>
      </div>
    </div>
    <a href="https://search-room.ch" target="_blank" rel="noopener noreferrer" class="sr-tooltip-link">
      Open Search Room →
    </a>
  `,t}async function c(){if(console.log("[Search Room] showOverlay called"),document.getElementById(d)){console.log("[Search Room] Overlay already exists");return}if(!y()){console.log("[Search Room] Not a supported domain, skipping overlay");return}try{const n=(await chrome.storage.sync.get("overlayEnabled")).overlayEnabled??!0;if(console.log("[Search Room] Overlay enabled setting:",n),!n){console.log("[Search Room] Overlay disabled in settings");return}}catch(e){console.error("[Search Room] Failed to get storage:",e)}console.log("[Search Room] Injecting overlay"),x();const t=v();document.body.appendChild(t);const o=document.getElementById(i);o&&o.addEventListener("click",w),console.log("[Search Room] Overlay injected successfully")}function p(){const t=document.getElementById(d);t&&t.remove(),s()}function s(){const t=document.getElementById(a);t&&t.remove()}function w(t){if(t.preventDefault(),t.stopPropagation(),document.getElementById(a)){s();return}k()}function k(){const t=b();document.body.appendChild(t);const o=t.querySelector(".sr-tooltip-close");o&&o.addEventListener("click",e=>{e.stopPropagation(),s()}),setTimeout(()=>{const e=n=>{const r=document.getElementById(a),l=document.getElementById(i);r&&l&&!r.contains(n.target)&&!l.contains(n.target)&&(s(),document.removeEventListener("click",e))};document.addEventListener("click",e)},100)}async function S(){console.log("[Search Room] initOverlay called, readyState:",document.readyState),document.readyState==="loading"?document.addEventListener("DOMContentLoaded",()=>{console.log("[Search Room] DOMContentLoaded fired"),c()}):setTimeout(()=>{c()},1e3);try{chrome.storage.onChanged.addListener((t,o)=>{o==="sync"&&t.overlayEnabled&&(console.log("[Search Room] Overlay setting changed:",t.overlayEnabled.newValue),t.overlayEnabled.newValue?c():p())})}catch(t){console.error("[Search Room] Failed to add storage listener:",t)}}chrome.runtime.onMessage.addListener((t,o,e)=>{if(t.type==="EXTRACT_CONTENT"){try{const n=u();e==null||e(n)}catch(n){console.error("[Search Room] Failed to extract content:",n),e==null||e({html:document.body.innerHTML,url:window.location.href,jsonLd:null,ogData:{},title:document.title})}return!0}else if(t.type==="OVERLAY_SETTING_CHANGED")return t.enabled?c():p(),!1;return!1});S();console.log("[Search Room] Content script loaded on:",window.location.hostname);
})()
